# Mini Project Data Engineering - Pro Max Version

## Các bước chạy
1. Clone project:
```bash
git clone <link>
cd mini-project-de
```

2. Chạy Docker:
```bash
docker-compose up --build
```

3. Enjoy! Tweets về Data Engineering sẽ tự động stream vào PostgreSQL.
