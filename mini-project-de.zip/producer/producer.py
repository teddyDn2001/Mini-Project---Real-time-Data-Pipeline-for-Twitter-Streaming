from kafka import KafkaProducer
import tweepy
import json
import os
import time

producer = KafkaProducer(bootstrap_servers='kafka:9092')

class StreamListener(tweepy.StreamListener):
    def on_status(self, status):
        tweet = {
            'user': status.user.screen_name,
            'text': status.text,
            'created_at': str(status.created_at)
        }
        producer.send('twitter-stream', json.dumps(tweet).encode('utf-8'))
        return True

auth = tweepy.OAuthHandler('CONSUMER_KEY', 'CONSUMER_SECRET')
auth.set_access_token('ACCESS_TOKEN', 'ACCESS_TOKEN_SECRET')

stream = tweepy.Stream(auth, StreamListener())

while True:
    try:
        stream.filter(track=['Data Engineering'])
    except Exception as e:
        print(f"Error: {e}")
        time.sleep(5)
