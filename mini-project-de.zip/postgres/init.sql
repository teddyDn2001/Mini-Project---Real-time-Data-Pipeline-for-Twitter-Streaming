CREATE TABLE IF NOT EXISTS tweets (
    user_name TEXT,
    tweet_text TEXT,
    created_at TIMESTAMP
);
