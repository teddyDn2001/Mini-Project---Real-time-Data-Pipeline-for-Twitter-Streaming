from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType

spark = SparkSession.builder     .appName("TwitterStreamProcessing")     .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0,org.postgresql:postgresql:42.6.0")     .getOrCreate()

schema = StructType()     .add("user", StringType())     .add("text", StringType())     .add("created_at", StringType())

df = spark.readStream.format("kafka")     .option("kafka.bootstrap.servers", "kafka:9092")     .option("subscribe", "twitter-stream")     .load()

tweets = df.selectExpr("CAST(value AS STRING)")     .select(from_json(col("value"), schema).alias("data"))     .select("data.*")

query = tweets.writeStream     .foreachBatch(lambda batch_df, batch_id: batch_df.write         .format("jdbc")         .option("url", "jdbc:postgresql://postgres:5432/twitterdb")         .option("dbtable", "tweets")         .option("user", "postgres")         .option("password", "yourpassword")         .option("driver", "org.postgresql.Driver")         .mode("append")         .save())     .start()

query.awaitTermination()
